import { Component, OnInit } from '@angular/core';
import {LoginUserService} from '../login-user.service';

@Component({
  selector: 'app-health-service-registration',
  templateUrl: './health-service-registration.component.html',
  styleUrls: ['./health-service-registration.component.css']
})
export class HealthServiceRegistrationComponent implements OnInit {

    facilitydata: any;
    servicetypedata: any;
    id: any;
    servicename: any;
    selectedfacilityid: any;
    selectedserviceid: any;

  constructor(
      private service: LoginUserService
  ) { }

  ngOnInit() {
        this.service.facilityLoad().subscribe(res => {
            this.facilitydata = res;
        });
        this.service.serviceLoad().subscribe(res => {
            this.servicetypedata = res;
        });
  }

    getSelectedOptionText(event) {
        this.selectedfacilityid = event.target.value;
    }

    getSelected(event) {
        this.selectedserviceid = event.target.value;
    }


    serviceregsubmit() {
        this.service.serviceregTuma(this.servicename, this.selectedfacilityid, this.selectedserviceid).subscribe(res => {
            // console.log(res);
        });
}

}
