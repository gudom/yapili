import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FacilityComponent } from './facility/facility.component';
import { ServicetypeComponent } from './servicetype/servicetype.component';
import { HealthServiceRegistrationComponent } from './health-service-registration/health-service-registration.component';
import { RegisteredServiceComponent } from './registered-service/registered-service.component';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FacilityComponent,
    ServicetypeComponent,
    HealthServiceRegistrationComponent,
    RegisteredServiceComponent,
    NavComponent,
    HomeComponent,

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
