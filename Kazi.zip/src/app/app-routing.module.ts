import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {FacilityComponent} from './facility/facility.component';
import {LoginComponent} from './login/login.component';
import {ServicetypeComponent} from './servicetype/servicetype.component';
import {HealthServiceRegistrationComponent} from './health-service-registration/health-service-registration.component';
import {HomeComponent} from "./home/home.component";

const routes: Routes = [
    {
        path: 'facility',
        component: FacilityComponent
    },
    {
        path: 'login',
        component: LoginComponent,
    },
    {
        path: 'servicetype',
        component: ServicetypeComponent,
    }, {
        path: 'home',
        component: HomeComponent,
    },
    {
        path: 'servicereg',
        component: HealthServiceRegistrationComponent,
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
