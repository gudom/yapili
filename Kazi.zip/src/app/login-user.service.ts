import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';


const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'any-auth-token'
    })
};


@Injectable({
  providedIn: 'root'
})
export class LoginUserService {

    private loginurl = 'http://localhost/healthreg/endpoints/public/login';
    private facilityurl = 'http://localhost/HealthReg/endpoints/public/register_facility';
    private servicetypetumaurl = 'http://localhost/HealthReg/endpoints/public/register_servicetype';
    private facility_load_url = 'http://localhost/HealthReg/endpoints/public/facility';
    private service_load_url = 'http://localhost/HealthReg/endpoints/public/viewservice';
    private serviceregtuma_url = 'http://localhost/HealthReg/endpoints/public/register_service';
    private loadallservice_url = 'http://localhost/HealthReg/endpoints/public/view';
  constructor(
      public http: HttpClient
  ) { }


  login(username: any, password: any) {
      // return this.http.get(this.loginurl + '/' + username + '/' + password);
      return this.http.get(this.loginurl + '/' + username + '/' + password);
  }


  facilityTuma(name, description) {
    return this.http.post(this.facilityurl,
        {
            'name': name,
            'description': description,
        }
        , httpOptions);
  }


  serviceTuma(name, description) {
      return this.http.post(this.servicetypetumaurl,
          {
              'name': name,
              'description': description,
          }
          , httpOptions);
  }


  facilityLoad() {
      return this.http.get(this.facility_load_url);
  }

  serviceLoad() {
      return this.http.get(this.service_load_url);
  }

  serviceregTuma(name, facility_id, servicety_id) {
      return this.http.post(this.serviceregtuma_url,
          {
              'name': name,
              'facility_id': facility_id,
              'service_id': servicety_id
          }
          , httpOptions);
  }


  loadAllRegisterdservice() {
      return this.http.get(this.loadallservice_url);
  }
}
