import { Component, OnInit } from '@angular/core';
import {LoginUserService} from '../login-user.service';

@Component({
  selector: 'app-facility',
  templateUrl: './facility.component.html',
  styleUrls: ['./facility.component.css']
})
export class FacilityComponent implements OnInit {

    facilityname: any;
    facilitydesc: any;

  constructor(
      private service_fac: LoginUserService
  ) { }

  ngOnInit() {
  }

    facilitySubmit() {
        this.service_fac.facilityTuma(this.facilityname, this.facilitydesc).subscribe(res => {
            // console.log(res);
        });
    }
}
