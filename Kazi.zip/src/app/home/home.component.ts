import { Component, OnInit } from '@angular/core';
import {LoginUserService} from '../login-user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    datas: any;
  constructor(
      private service: LoginUserService
  ) { }

  ngOnInit() {
        this.service.loadAllRegisterdservice().subscribe(res => {
            this.datas = res;
        });
  }


}
