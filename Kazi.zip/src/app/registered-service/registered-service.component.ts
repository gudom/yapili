import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registered-service',
  templateUrl: './registered-service.component.html',
  styleUrls: ['./registered-service.component.css']
})
export class RegisteredServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
