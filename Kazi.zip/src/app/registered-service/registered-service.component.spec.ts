import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisteredServiceComponent } from './registered-service.component';

describe('RegisteredServiceComponent', () => {
  let component: RegisteredServiceComponent;
  let fixture: ComponentFixture<RegisteredServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisteredServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteredServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
