<?php
/**
 * Created by PhpStorm.
 * User: Hebron
 * Date: 2/13/2019
 * Time: 7:30 AM
 */

$container = $app->getContainer();
$container['db'] = function ($c){
    $setting = $c->get('settings')['db'];
    $pdo = new PDO("mysql:host={$setting['host']};dbname={$setting['db_name']}","{$setting['username']}","{$setting['password']}");
//    $pdo = new PDO("mysql:host=localhost;dbname=test",'root','');

    return $pdo;
};